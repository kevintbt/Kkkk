GESTOR MIXSHOP 21.4 — PROJETO ANDROID

Este pacote é um projeto-fonte Android Studio com WebView local, usando o aplicativo HTML 21.4.
Inclui JavaScript, armazenamento local do navegador e seletor de arquivos para escolher fotos dos produtos.

COMO GERAR O APK:
1. Instale Android Studio em um computador.
2. Abra a pasta Gestor_Mixshop_Android.
3. Aguarde a sincronização do Gradle e instale os componentes Android SDK solicitados.
4. No menu Build, escolha Build Bundle(s) / APK(s) > Build APK(s).
5. O APK de depuração será gerado em app/build/outputs/apk/debug/app-debug.apk.

IMPORTANTE:
- Este ambiente não possui Android SDK/Gradle instalados, portanto não foi possível compilar nem testar um APK instalável aqui.
- Os dados ficam no armazenamento local do app/dispositivo. Não existe sincronização em nuvem.
- Para publicar na Play Store, será necessário configurar assinatura e política de privacidade.
