GESTOR MIXSHOP 21.4 — PACOTE PREPARADO PARA CODEMAGIC

O QUE ESTE PACOTE FAZ
- Empacota a versão web 21.4 dentro de um aplicativo Android (WebView).
- Mantém o seletor de fotos para cadastrar imagens de produtos.
- Inclui configuração Codemagic para compilar APK automaticamente na nuvem.
- A compilação gera um APK de depuração (debug), adequado para instalação e testes.

COMO GERAR O APK PELO CODEMAGIC
1. Extraia este ZIP no computador ou celular.
2. Crie um repositório no GitHub e envie TODO o conteúdo desta pasta para a raiz do repositório.
   O arquivo codemagic.yaml deve ficar na raiz, ao lado de settings.gradle e build.gradle.
3. Crie/entre em https://codemagic.io/ e conecte sua conta GitHub.
4. Adicione o repositório Gestor Mixshop no Codemagic.
5. Escolha o workflow "gestor-mixshop-apk" (definido em codemagic.yaml).
6. Inicie a build. Ao terminar, abra Artifacts e baixe o arquivo APK.
7. Envie o APK ao celular Android e autorize a instalação de aplicativos dessa origem, se o Android solicitar.

SE O CODEMAGIC NÃO DETECTAR O WORKFLOW
- Confira se codemagic.yaml está na raiz do repositório (não dentro de uma subpasta).
- Faça commit e push do arquivo.
- Recarregue a configuração do app no Codemagic.

DETALHES TÉCNICOS
- Android Gradle Plugin: 8.6.1
- Gradle Wrapper criado durante a build: 8.7
- Java: 17
- applicationId: com.mixshop.gestor
- APK esperado: app/build/outputs/apk/debug/app-debug.apk

IMPORTANTE
- O ambiente Codemagic gera o APK; este pacote não é um APK pronto.
- É um APK debug para instalação/teste. Para distribuição ampla ou Play Store, configure assinatura de release.
- Os dados são locais ao aplicativo/dispositivo; não há backend nem sincronização em nuvem.
